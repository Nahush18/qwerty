/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myservice;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author nahus
 */
@WebService(serviceName = "CelToFarWebService")
public class CelToFarWebService {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "celtofar")
    public Double celtofar(@WebParam(name = "num1") double num1) {
        //TODO write your implementation code here:
        return (((num1*9)/5)+32);
    }

    /**
     * This is a sample web service operation
     */
    
}
