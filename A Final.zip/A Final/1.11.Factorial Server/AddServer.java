import java.rmi.*;
import java.rmi.registry.*;

public class AddServer {
    public static void main(String args[]) {
        try {
            // Create the remote object
            AddServerImpl addServerImpl = new AddServerImpl();
            // Bind the remote object in the RMI registry
            Naming.rebind("AddServer", addServerImpl);
            System.out.println("AddServer is ready to serve requests.");
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}

