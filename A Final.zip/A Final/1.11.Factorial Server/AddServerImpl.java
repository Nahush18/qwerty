import java.rmi.*;
import java.rmi.server.*;
import java.math.BigInteger; // Import BigInteger

public class AddServerImpl extends UnicastRemoteObject implements AddServerIntf {
    // Constructor
    public AddServerImpl() throws RemoteException {}

    // Method to calculate factorial using BigInteger
    public BigInteger fct(int c) throws RemoteException {
        BigInteger fact = BigInteger.ONE; // Start with BigInteger.ONE (equivalent to 1)
        for (int i = 1; i <= c; i++) {
            fact = fact.multiply(BigInteger.valueOf(i)); // Multiply with each number
        }
        return fact;
    }
}

