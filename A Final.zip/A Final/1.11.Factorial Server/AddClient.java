import java.rmi.*;
import java.math.BigInteger; // Import BigInteger for handling large numbers

public class AddClient {
    public static void main(String args[]) {
        try {
            // Get reference to the remote object
            String addServerURL = "rmi://" + args[0] + "/AddServer";
            AddServerIntf addServerIntf = (AddServerIntf) Naming.lookup(addServerURL);

            // Convert the argument to an integer
            int d1 = Integer.parseInt(args[1]);

            // Get the factorial result
            BigInteger result = addServerIntf.fct(d1);

            // Print the result
            System.out.println("The factorial of " + d1 + " is: " + result);
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}

