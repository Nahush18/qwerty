/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.myservice.SINewService_Service;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.WebServiceRef;

/**
 *
 * @author nahus
 */
public class SIServlet extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/SINew/SINewService.wsdl")
    private SINewService_Service service;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
    double num1, num2, num3;
    num1 = Double.parseDouble(request.getParameter("num1"));
    num2 = Double.parseDouble(request.getParameter("num2"));
    num3 = Double.parseDouble(request.getParameter("num3"));
    out.println("<!DOCTYPE html>");
    out.println("<html lang='en'>");
    out.println("<head>");
    out.println("<meta charset='UTF-8'>");
    out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
    out.println("<title>Simple Interest Calculator</title>");
    out.println("</head>");
    out.println("<body style='font-family: Arial, sans-serif; background-color: #f4f7fc; margin: 0; padding: 0; display: flex; justify-content: center; align-items: center; height: 100vh;'>");

    out.println("<div style='background-color: #ffffff; border-radius: 10px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); padding: 30px; width: 100%; max-width: 400px; text-align: center;'>");
    out.println("<h1 style='color: deepskyblue; font-size: 24px; margin-bottom: 20px;'>Simple Interest Calculator</h1>");
    out.println("<h2 style='color: #333; font-size: 20px; margin-top: 30px;'>The Simple Interest is: <span style='color: deepskyblue;'>" + siCalculate(num1, num2, num3) + "</span></h2>");
    out.println("<br>");
    out.println("<a href='index.html' style='text-decoration: none; font-size: 16px; color: deepskyblue; background-color: #ffffff; border: 2px solid deepskyblue; padding: 10px 20px; border-radius: 5px; transition: background-color 0.3s ease;'>Go Back</a>");
    out.println("</div>");

    out.println("</body>");
    out.println("</html>");
}

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private Double siCalculate(double num1, double num2, double num3) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        com.myservice.SINewService port = service.getSINewServicePort();
        return port.siCalculate(num1, num2, num3);
    }
    
    
}
