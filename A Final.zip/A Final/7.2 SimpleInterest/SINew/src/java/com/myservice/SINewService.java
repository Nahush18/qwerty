/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myservice;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author nahus
 */
@WebService(serviceName = "SINewService")
public class SINewService {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "SICalculate")
    public Double SICalculate(@WebParam(name = "num1") double num1, @WebParam(name = "num2") double num2, @WebParam(name = "num3") double num3) {
        //TODO write your implementation code here:
        return ((num1*num2*num3)/100);
    }

    /**
     * This is a sample web service operation
     */
    
}
