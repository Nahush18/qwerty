import java.rmi.*;
import java.rmi.server.*;

// class that implements the remote interface
public class AddServerImpl extends UnicastRemoteObject implements AddServerIntf {
    
    // constructor
    public AddServerImpl() throws RemoteException {
        super();
    }

    // implement method declared in the interface
    public double ctof(double c) throws RemoteException {
        // Correct formula for Celsius to Fahrenheit conversion
        double celtofah = (c * (9.0 / 5.0)) + 32;
        return celtofah;
    }
}

