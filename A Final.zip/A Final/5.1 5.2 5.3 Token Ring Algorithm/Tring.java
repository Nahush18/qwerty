import java.util.Scanner;

class Tring {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);

        // Taking the number of nodes as input
        System.out.print("Enter the number of nodes: ");
        int n = sc.nextInt();

        // Check for valid number of nodes (must be greater than 0)
        if (n <= 0) {
            System.out.println("Error: Number of nodes must be greater than 0.");
            return;
        }

        // Decides the number of nodes forming the ring
        int token = 0;

        // Printing the nodes in the ring
        System.out.print("Nodes in the ring: ");
        for (int i = 0; i < n; i++) {
            System.out.print(" " + i);
        }
        System.out.println(" " + 0);

        try {
            while (true) {
                // Input for sender, receiver, and data
                System.out.print("Enter sender: ");
                int s = sc.nextInt();

                // Check for valid sender input
                if (s < 0 || s >= n) {
                    System.out.println("Error: Sender must be between 0 and " + (n - 1));
                    continue;
                }

                System.out.print("Enter receiver: ");
                int r = sc.nextInt();

                // Check for valid receiver input
                if (r < 0 || r >= n) {
                    System.out.println("Error: Receiver must be between 0 and " + (n - 1));
                    continue;
                }

                System.out.print("Enter Data: ");
                String d = sc.next();

                // Token passing
                System.out.print("Token passing: ");
                // Current token not equal to sender, increment i by 1 and j by (j+1)%n
                for (int i = token, j = token; (i % n) != s; i++, j = (j + 1) % n) {
                    System.out.print(" " + j + "->");
                }
                System.out.println(" " + s);

                System.out.println("Sender " + s + " sending data: " + d);

                // Start forwarding data from node after sender until it becomes equal to receiver
                for (int i = (s + 1) % n; i != r; i = (i + 1) % n) {
                    System.out.println("Data " + d + " forwarded by " + i);
                }
                System.out.println("Receiver " + r + " received data: " + d);
                token = s; // Update the token to the sender
            }
        } catch (Exception e) {
            System.out.println("Error occurred: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
