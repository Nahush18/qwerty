import java.rmi.*;

public class AddClient {
    public static void main(String args[]) {
        try {
            // Get reference to the remote object
            String addServerURL = "rmi://" + args[0] + "/AddServer";
            AddServerIntf addServerIntf = (AddServerIntf) Naming.lookup(addServerURL);
            
            // Print the input string
            System.out.println("The String: " + args[1]);
            
            // Get the string passed and count the vowels
            String inputString = args[1];
            System.out.println("Count of Vowels: " + addServerIntf.cvwl(inputString));
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
    }
}

